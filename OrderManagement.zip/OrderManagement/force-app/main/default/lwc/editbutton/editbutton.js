import { LightningElement, api } from 'lwc';

import ACCOUNTNAME_FIELD from '@salesforce/schema/Order.AccountId';
import ORDERSTARTDATE_FIELD from '@salesforce/schema/Order.EffectiveDate';
import CONTRACTNUMBER_FIELD from '@salesforce/schema/Order.ContractId';
import STATUS_FIELD from '@salesforce/schema/Order.Status';
import ORDERREMARK_FIELD from '@salesforce/schema/Order.Order_Remarks__c';

export default class Editbutton extends LightningElement {
    @api recordId;
    @api objectApiName;

    fields = [ACCOUNTNAME_FIELD,
    ORDERSTARTDATE_FIELD,
    CONTRACTNUMBER_FIELD,
    STATUS_FIELD,
    ORDERREMARK_FIELD];
}