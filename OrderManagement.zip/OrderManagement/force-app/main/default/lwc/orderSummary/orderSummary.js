import { LightningElement, wire, track, api } from 'lwc';
import getAllOrders from '@salesforce/apex/orderSummaryController.getAllOrders'
import submitForApproval from '@salesforce/apex/submitForApproval.submitForApproval';
import cancelStatus from '@salesforce/apex/cancelOrder.cancelStatus';
import updateOrderItem from '@salesforce/apex/orderSummaryController.updateOrderItem';
import deleteOrderItem from '@salesforce/apex/orderSummaryController.deleteOrderItem';

export default class OrderSummary extends LightningElement {
    //@track
    //orders;
    @track
    Orders = [];
    @track
    OrderItemDetails = [];
    @track
    ind;
    @track
    indOuterLoop;
    @track
    indInnerLoop;
    //updateClicked = false;
    @track
    totalQuan = 0;
    quan;

    @wire(getAllOrders)
    WiredOrders({ error, data }) {
        if (data) {
            console.log(data);
            for (var i = 0; i < data.length; i++) {
                this.totalQuan = 0;
                this.OrderItemDetails = [];
                if (data[i].TotalAmount != 0) {
                    for (var j = 0; j < data[i].OrderItems.length; j++) {
                        this.OrderItemDetails.push({
                            'OrderItemId': data[i].OrderItems[j].Id,
                            'Name': data[i].OrderItems[j].PricebookEntry.Product2.Name,
                            'ProductCode': data[i].OrderItems[j].PricebookEntry.Product2.ProductCode,
                            'Brand__c': data[i].OrderItems[j].PricebookEntry.Product2.Brand__c,
                            'Stock_Quantity__c': data[i].OrderItems[j].PricebookEntry.Product2.Stock_Quantity__c,
                            'Quantity': data[i].OrderItems[j].Quantity,
                            'showButton':false
                        });
                        this.totalQuan += data[i].OrderItems[j].Quantity;
                    }
                    this.Orders.push({
                        'OrderId': data[i].Id,
                        'OrderNumber': data[i].OrderNumber,
                        'Amountpayable__c':data[i].Amountpayable__c,
                        'TotalAmount': data[i].TotalAmount,
                        'TotalQuantity': this.totalQuan,
                        'Order_Stages__c':data[i].Order_Stages__c,
                        'showConfirm':(data[i].Order_Stages__c=='Created'?true:false),
                        'OrderItemDetails': this.OrderItemDetails
                    });
                }
            }
        }
        if(error)
        console.log('Error in fetching data' + error);
    }
    onChangeQuantity(event){
        this.quan = event.target.value;
    }
    handleConfirm(event){
        this.ind = event.target.value;
        //console.log(this.Orders[this.ind].Order_Stages__c);
        //console.log(this.Orders[this.ind].showConfirm);
        submitForApproval({opp: this.Orders[this.ind].OrderId});
        if (this.Orders[this.ind].Order_Stages__c!='Created') 
        {
            this.Orders[this.ind].showConfirm=false;
            console.log(this.Orders[this.ind].Order_Stages__c)
        }
        console.log(this.Orders[this.ind].showConfirm);
        location.reload();
    }
    handleCancel(event){
        this.ind = event.target.value;
        cancelStatus({orderId: this.Orders[this.ind].OrderId});
        location.reload();
    }
    handleUpdate(event){
        //this.updateClicked = true;
        this.indOuterLoop = event.target.dataset.i;
        this.indInnerLoop = event.target.dataset.j;
        this.Orders[this.indOuterLoop].OrderItemDetails[this.indInnerLoop].showButton=true;
    }
    handleDelete(event){
        this.indOuterLoop = event.target.dataset.i;
        this.indInnerLoop = event.target.dataset.j;
        deleteOrderItem({orderId: this.Orders[this.indOuterLoop].OrderId,
                        itemId: this.Orders[this.indOuterLoop].OrderItemDetails[this.indInnerLoop].OrderItemId,
                        });
        location.reload();
    }
    saveClicked(event){
        this.indOuterLoop = event.target.dataset.i;
        this.indInnerLoop = event.target.dataset.j;
        updateOrderItem({orderId: this.Orders[this.indOuterLoop].OrderId,
                         itemId: this.Orders[this.indOuterLoop].OrderItemDetails[this.indInnerLoop].OrderItemId,
                         quantity: this.quan});
        location.reload();
    }
    cancelClicked(event){
        this.indOuterLoop = event.target.dataset.i;
        this.indInnerLoop = event.target.dataset.j;
        this.Orders[this.indOuterLoop].OrderItemDetails[this.indInnerLoop].showButton=false;
    }
}